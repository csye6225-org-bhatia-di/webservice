exports.fetchHealthInfo = async (req, res) => {
    console.log("Health controller");
    return res.status(200).send();

}