var assert = require('assert');

describe('Testing Github workflow', function() {
    it('Test boolean values', function () {
        var b = true;
        assert.equal(true, b);
    });
  });